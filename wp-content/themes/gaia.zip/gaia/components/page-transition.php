<div class="page-transition">
    <div class="page-transition__container">
    </div>
</div>