const test = () => {
  console.log("Hello from the test module");
  console.log(`GSAP Library Version: ${gsap.version}`);
};

export default test;
