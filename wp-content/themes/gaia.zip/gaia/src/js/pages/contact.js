const contact = () => {
  console.log("Hello from Contact");
};

contact();

export default contact;
