import test from "../logic/test.js";

const team = () => {
  console.log("Hello from Team");

  test();
};

team();

export default team;
