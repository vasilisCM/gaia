const posts = () => {
  console.log("Hello from Posts");
};

posts();

export default posts;
