# boilerplate-dynamic
Boilerplate code for WordPress with JS modules configured and loaded in functions.php
